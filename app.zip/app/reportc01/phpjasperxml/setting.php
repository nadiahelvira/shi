<?php
$server="localhost:3306";
$db="januar14_ptbum";
$user="root";
$pass="123456";
$version="0.9d";
$pgport=5432;
$pchartfolder="class/pchart2";
